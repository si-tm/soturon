
#oxdna input config
oxdna_input = "input_relax_1e2"#debag

#result directory
results_dir = "../results"

#pool config

poolnum = 1

oxDNA_dir = "../../oxDNA"